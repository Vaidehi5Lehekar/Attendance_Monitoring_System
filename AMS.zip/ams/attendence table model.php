<?php
//getting usefull libraries to work with spreadsheets
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;


//we will enter following php code only when submit button of form has some value
if (isset($_POST["submit_button"])) {
    
  //setting up database connection
$servername = "127.0.0.1:3307";
$username = "root";
$password = "yash2001";
$db="ams";
$con = mysqli_connect($servername , $username, $password , $db);

if(!$con){
  die("connection failed due to the following error  " . $con->connect_error);
}
else{





//valid extentions
$allowed_files = ["xls" , "csv" , "xlsx"];

//split the name revesived fro, user along .
$file_name = $_FILES['myfile']['name'];
$checking = explode("." , $file_name);
$extention=end($checking);
//checking if extention is is valid or not
  if ( in_array($extention , $allowed_files) ) {
    
    $target_path = $_FILES['myfile']["tmp_name"];
    
      if ($extention == "xls" or $extention=="xlsx") {
        //creating a reader to read xls or xlsx file
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($target_path);
        
      } 
      if ($extention=="csv") {
        //reader for csv file
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        $reader->setDelimiter(",");
        $spreadsheet = $reader->load($target_path);
    
      }


    //storing sheet into array named student
    $student = $spreadsheet->getActiveSheet()->toArray();

    // calculating meeting time
    $meeting_start_array =explode("," , $student[3][1] ) ;
    $meeting_start=reset($meeting_start_array);
    echo "<br> $meeting_start";
    $to_time = strtotime($student[3][1]);
    echo "<br> $to_time";
    $from_time = strtotime($student[4][1]);
    $meeting_time = round(abs($to_time - $from_time) / 60,2);
    echo "<br> $meeting_time";
    //array to store attendence result of each student
    $attendence=array();
    //getting each element of  every row 
    for($i=8 ; $i<count($student) ; $i++) {

      //getting prn out of mail
      $email=$student[$i][4];
      $email_array=explode('@' , $email);
      $prn = reset($email_array);
      
      if($prn != "checked"){
        // calculating the time for which student was preesnt in meeting
        $email_for_traverse=$student[$i][4];
        $to_time = strtotime($student[$i][1]);
        $from_time = strtotime($student[$i][2]);
        $duration = round(abs($to_time - $from_time) / 60,2);
        //calculating total time for which student was present in meeting
        for ($y=$i+1; $y < count($student) ; $y++) { 
          if($student[$y][4]==$email_for_traverse){
            $to_time = strtotime($student[$y][1]);
            $from_time = strtotime($student[$y][2]);
            $duration+= round(abs($to_time - $from_time) / 60,2);
            $student[$y][4]="checked";
            
          }
        }
        //calculating ratio for time for which student should be in meet in order to be marked present
        $compulsion= (isset($_POST['compulsion']) ? $_POST['compulsion'] : 100);
        $ratio= round($compulsion/100 , 2);
        //considering  student that were present for more that compulsion time
        $department=(isset($_POST['department_name']) ? $_POST['department_name'] : '');
          $subject=(isset($_POST['subject']) ? $_POST['subject'] : '');

        if ($duration>=$meeting_time*$ratio) {
            
            $try_insert = mysqli_query($con,"INSERT INTO `attendence`(`Lecture_date`,`prn` ,`subject` , `status`) VALUES ( STR_TO_DATE('$meeting_start', '%m/%d/%Y') , '$prn' , '$subject' , '1')");
           if($try_insert==true){
            array_push($attendence,"<br> prn " .  $prn . " is marked PRESENT (updated) !");
           }
           else {
             array_push($attendence,"<br> prn " .  $prn . " is is not part of student database");
           }

        }
        
        else 
        {
          $try_insert = mysqli_query($con,"INSERT INTO `attendence`(`Lecture_date`,`prn` ,`subject` , `status`) VALUES ( STR_TO_DATE('$meeting_start', '%m/%d/%Y') , '$prn' , '$subject' , '0')");
          if($try_insert==true){
            array_push($attendence,"<br> prn " .  $prn . " is marked ABSENT (updated) !");
           }
           else {
             array_push($attendence,"<br> prn " .  $prn . " is is not part of student database");
           }
        }
      }
      else {
        if ($prn=="checked") 
        {
          continue;
        }
      }
     
    };
    

    }
  


}
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>accept attendence</title>
    
    <style>
  <?php include "index.css" ?>
</style>

</head>
<body>
    <div class="container">
        <h1>WElCOME , TEACHER :)</h1>
        <p> Submit Your Attendence sheet below</p>
        
    </div>
    <div class="warning" >
        <h5>PLease make sure that attendence report is not in UNICODE TEXT format</h5>
        <p>please save attendence report as "xlxs" or "xls" or "utf-8 csv" before uploading it here.</p>

        
        <div class="attendence">
        <?php
        if (isset($_POST["submit_button"]))
        {
          foreach ($attendence as $key) {
            echo trim($key);
          }
        }
        ?>
        </div>
        

          

        
    </div>

    <form action="attendence table model.php" method="post" enctype="multipart/form-data" >
      
       <div> <label for="department_dropdown">select department</label>
        <select id="department_dropdown" name="department_name" required>
            <option value=""></option>
            <option value="cs" >Computer Science</option>
            <option value="mechanical" onclick="mech_function">Mechanical</option>
            <option value="entc" onclick="entc_function" >Electronic and Tele.</option>
          </select>
        </div>

  <div>      <label for="Subject">Choose a Subject:</label>
    <select  name="subject" id="subject">
      
      <optgroup label="Mechanical">
        <option value=9 >aerodynamics</option>
        <option value=10 >engines</option>
        <option value=11 >fluid mechanics</option>
        <option value=12 >pressure systems</option>
      </optgroup>
    
      <optgroup label="Computer Science">
        <option value=1>CNS</option>
        <option value=2>SPOS</option>
        <option value=3>DBMS</option>
        <option value=4>EL</option>
      </optgroup>
    
      <optgroup label="ENTC">
        <option value=5>a</option>
        <option value=6>b</option>
        <option value=7>c</option>
        <option value=8>d</option>
      </optgroup>
    </select>
    </div>

    <div>
      <label for="compulsion_time">Enter % of conpulsion Time</label>
      <input type="number" id="compulsion_time" name="compulsion">
    </div>

    <div>
      <label for="myfile">Select a file:</label>
      <input type="file" id="myfile" name="myfile"></div>
      <div>
        <button type="submit" name="submit_button">SubmitS</button>
      </div>
    </form>
    
    <script src="index.js"></script>
</body>
</html>

