<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    hello bopy this is our first php website
    <?php 
    echo("this text is written in php");
    //comment
    ?>

   <div  style=" color: red;"> <?php 
    //variables in php
    $coder = "yash";
    echo ("You are coding with ");
    echo ($coder);
    ?>
</div>

<?php
    //operators in php
    /* arhtematic
    assignment
    comparision
    increment */

    //arthematic
    $var1= 34;
    $var2 = 2;
    echo ("<h1>operator examples</h1><br>");
    echo ($var1);
    echo " + ";
    echo $var2;
    echo "  =  ";
    echo $var1 + $var2;
    echo "<br><br>";
    
    echo ($var1);
    echo " - ";
    echo $var2;
    echo "  =  ";
    echo $var1 - $var2;
    echo "<br><br>";

    echo ($var1);
    echo " * ";
    echo $var2;
    echo "  =  ";
    echo $var1 * $var2;
    echo "<br><br>";

    echo ($var1);
    echo " / ";
    echo $var2;
    echo "  =  ";
    echo $var1 / $var2;
    echo "<br><br>";


    //asignment operator = += -=
    //comparision operator > < >= <=
    // logical operatror and or xor
?>

<?php 
  /*   Datatypes in php
    String
    integer
    boolean 
    Float
    Array 
    Object  */

    $var = "this is a beautifull String";
    echo    var_dump($var);
    echo    "<br>";
    
    $var = TRUE;
    echo    var_dump($var);
    echo    "<br>";

    $var = array(23,45,4667,78);
    echo    var_dump($var);
    echo    "<br>";

    $var = "this is a beautifull String";
    echo    var_dump($var);
    echo    "<br>";

//CONSTANTS IN PHP
    define("prn" , "72028008H");
    echo " <br>";
    echo prn;
    echo " is the constant defined in our Program ";
    echo "<br>";
    echo var_dump(prn);

?>
<br><br>
<a href="index.html"><b>More Basics...</b></a>
</body>
</html>