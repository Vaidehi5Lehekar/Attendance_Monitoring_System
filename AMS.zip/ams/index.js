function cs_function() {
    var x = document.getElementById("divisions_cs");
    if (x.style.display == "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
  }