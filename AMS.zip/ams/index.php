<?php
//getting usefull libraries to work with spreadsheets
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;


//we will enter following php code only when submit button of form has some value
if (isset($_POST["submit_button"])) {
    
  //setting up database connection
$servername = "127.0.0.1:3307";
$username = "root";
$password = "yash2001";
$db="ams";
$con = mysqli_connect($servername , $username, $password , $db);

if(!$con){
  die("connection failed due to the following error  " . $con->connect_error);
}
else{





//valid extentions
$allowed_files = ["xls" , "csv" , "xlsx"];

//split the name revesived fro, user along .
$file_name = $_FILES['myfile']['name'];
$checking = explode("." , $file_name);
$extention=end($checking);
//checking if extention is is valid or not
  if ( in_array($extention , $allowed_files) ) {
    
    $target_path = $_FILES['myfile']["tmp_name"];
    
      if ($extention == "xls" or $extention=="xlsx") {
        //creating a reader to read xls or xlsx file
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($target_path);
        
      } 
      if ($extention=="csv") {
        //reader for csv file
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        $reader->setDelimiter(",");
        $spreadsheet = $reader->load($target_path);
    
      }


    //storing sheet into array named student
    $student = $spreadsheet->getActiveSheet()->toArray();

    // calculating meeting time
    $to_time = strtotime($student[3][1]);
    $from_time = strtotime($student[4][1]);
    $meeting_time = round(abs($to_time - $from_time) / 60,2);
    //array to store attendence result of each student
    $attendence=array();
    //getting each element of  every row 
    for($i=8 ; $i<count($student) ; $i++) {

      //getting prn out of mail
      $email=$student[$i][4];
      $email_array=explode('@' , $email);
      $prn = reset($email_array);
      
      //checking if prn is PRESENT in student table andtaking further actions if present
      $prn_check_query= " SELECT prn FROM student where prn = '$prn' ";
      $returned_records=  mysqli_query($con,$prn_check_query);
      if(mysqli_num_rows($returned_records)==1){
        // calculating the time for which student was preesnt in meeting
        $email_for_traverse=$student[$i][4];
        $to_time = strtotime($student[$i][1]);
        $from_time = strtotime($student[$i][2]);
        $duration = round(abs($to_time - $from_time) / 60,2);
        //calculating total time for which student was present in meeting
        for ($y=$i+1; $y < count($student) ; $y++) { 
          if($student[$y][4]==$email_for_traverse){
            $to_time = strtotime($student[$y][1]);
            $from_time = strtotime($student[$y][2]);
            $duration+= round(abs($to_time - $from_time) / 60,2);
            $student[$y][4]="checked";
            
          }
        }
        //calculating ratio for time for which student should be in meet in order to be marked present
        $compulsion= (isset($_POST['compulsion']) ? $_POST['compulsion'] : 100);
        $ratio= round($compulsion/100 , 2);
        

        //considering  student that were present for more that compulsion time
        if ($duration>=$meeting_time*$ratio) {
          $department=(isset($_POST['department_name']) ? $_POST['department_name'] : '');
          $subject=(isset($_POST['subject']) ? $_POST['subject'] : '');


          //chechking if student is present in department table or not
          $prn_check_query= "SELECT prn FROM $department where prn = '$prn' ";
          $subject_result=  mysqli_query($con,$prn_check_query);
          //if student present in department table update table with student attendence
          if (mysqli_num_rows($subject_result)==1) {
            $check_error = mysqli_query($con , "UPDATE $department SET `$subject`=`$subject`+'1' WHERE `prn`= '$prn'");
           
            array_push($attendence," prn " .  $prn . ' is marked <span id="green"> PRESENT</span>  (updated) !');
          }
          //if student is not present in department table we insert into department table
          else {
            $prn_check_query="INSERT INTO `$department` (`prn`, `$subject`) VALUES ('$prn', '1');";
            if (mysqli_query($con, $prn_check_query)==true) 
            {
            array_push($attendence," prn " .  $prn . 'is marked <span id="green"> PRESENT</span>  (inserted) !');
            }
            else 
            {
            array_push($attendence, " failed to insert attendence of " .$prn ." in database");
            }
          }
        }
        else 
        {
          array_push($attendence," prn " .  $prn . ' is marked <span id="red"> ABSENT</span> (updated) !');
        }
      }
      else {
        if ($prn=="checked") 
        {
          continue;
        }
        else 
        {
          array_push($attendence, " prn " .  $prn . '<span id="red"> NOT FOUND</span> in college database !');
        }
      }
     
    };
    

    }
  


}
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>accept attendence</title>
    
    <style>
  <?php include "index.css" ?>
</style>

</head>
<body>
    <div class="container">
        <h1>WElCOME , TEACHER :)</h1>
        <p> Submit Your Attendence sheet below</p>
        
    </div>
    <div class="warning" >
        <h5>PLease make sure that attendence report is not in UNICODE TEXT format</h5>
        <p>please save attendence report as "xlxs" or "xls" or "utf-8 csv" before uploading it here.</p>

        <br><br><br>
        <div class="attendence">
        <?php
        if (isset($_POST["submit_button"]))
        {
          echo '<div class="output">';
          
          foreach ($attendence as $key) {
            echo '<div class="row" >' .trim($key).'</div>' ;
          }
          
          echo '</div>';
        }
        ?>
        </div>
        

          

        
    </div>

    <form action="index.php" method="post" enctype="multipart/form-data" >
       <div> <label for="department_dropdown">select department</label>
        <select id="department_dropdown" name="department_name" required>
            <option value=""></option>
            <option value="cs" onclick="cs_function()">Computer Science</option>
            <option value="mechanical" onclick="mech_function">Mechanical</option>
            <option value="entc" onclick="entc_function" >Electronic and Tele.</option>
          </select>
        </div>

  <div>      <label for="Subject">Choose a Subject:</label>
    <select  name="subject" id="subject">
      
      <optgroup label="Mechanical">
        <option value="aerodynamics">aerodynamics</option>
        <option value="engines">engines</option>
        <option value="fluid mechanics">fluid mechanics</option>
        <option value="pressure systems">pressure systems</option>
      </optgroup>
    
      <optgroup label="Computer Science">
        <option value="cns">CNS</option>
        <option value="spos">SPOS</option>
        <option value="dbms">DBMS</option>
        <option value="el">EL</option>
      </optgroup>
    
      <optgroup label="ENTC">
        <option value="a">a</option>
        <option value="b">b</option>
        <option value="c">c</option>
        <option value="d">d</option>
      </optgroup>
    </select>
    </div>

    <div>
      <label for="compulsion_time">Enter % of conpulsion Time</label>
      <input type="number" id="compulsion_time" name="compulsion">
    </div>

    <div>
      <label for="myfile">Select a file:</label>
      <input type="file" id="myfile" name="myfile"></div>
      <div>
        <button type="submit" name="submit_button">SubmitS</button>
      </div>
    </form>

    <a href="students.php"><button >Add Students in Database</button></a>
       
        <a href="fetch.php"><button >View Attendence</button></a>
    
    <script src="index.js"></script>
</body>
</html>

