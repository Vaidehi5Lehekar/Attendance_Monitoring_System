<?php
//getting usefull libraries to work with spreadsheets

//we will enter following php code only when submit button of form has some value
if (isset($_POST["view_attendence"])) {
    
  //setting up database connection
$servername = "127.0.0.1:3307";
$username = "root";
$password = "yash2001";
$db="ams";
$con = mysqli_connect($servername , $username, $password , $db);

if(!$con){
  die("connection failed due to the following error  " . $con->connect_error);
}
else{
 $department=$_POST['department_name'];
 $division=$_POST['Division'];

 //$Fetch_Result= mysqli_query($con, "SELECT * from $department   where `prn`in (SELECT `prn` from `student` where `student_div`= '$division')");
 //$Fetch_Result = mysqli_query($con, "SELECT $department.* ,`student`.`student_name` from $department ,`student` where $department.`prn` and `student`.`prn` in (SELECT `prn` from `student` where `student_div`= '$division') ");
 $Fetch_Result= mysqli_query($con, "SELECT d.* , s.`student_name` from $department as d inner join `student`as s on d.`prn`=s.`prn` where d.`prn`in (SELECT `prn` from `student` where `student_div`= '$division')");
 


 }
   

}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>accept attendence</title>
    
<style>
  <?php include "fetch.css" ?>
</style>

</head>
<body>
    <div class="container">
        <h1>WElCOME , TEACHER :)</h1>
        <p>  View nStudent attn below</p>
        
    </div>

    <div class="result">
      <?php 
      if (isset($_POST['view_attendence'])) {
        if ( mysqli_num_rows($Fetch_Result) > 0) {
          // output data of each row
          $all_property = array();  //declare an array for saving property

//showing property
echo '<table class="data-table">
        <tr class="data-heading">';  //initialize table tag


while ($property = mysqli_fetch_field($Fetch_Result)) 
{
  if ($property->name != "sr no") 
  {
    echo '<th>' . $property->name . '</th>';  //get field name for header
    array_push($all_property, $property->name);  //save those to array
  }
}
echo '</tr>'; //end tr tag



//showing all data
while ($row = mysqli_fetch_array($Fetch_Result)) 
{
    echo "<tr>";
    foreach ($all_property as $item) 
    {
        echo '<td>' . $row[$item] . '</td>'; //get items using property value
    }
    echo '</tr>';
}
echo "</table>";


        }
        else {
          echo "0 results";
        }
        
        mysqli_close($con);
      }
       
      ?>
    </div>

    <table>
      <tr></tr>
    </table>

    <form action="fetch.php" method="post" enctype="multipart/form-data" >

    <div> <label for="department_dropdown">select department</label>
        <select id="department_dropdown" name="department_name" required>
            <option value=""></option>
            <option value="cs" >Computer Science</option>
            <option value="mechanical" onclick="mech_function">Mechanical</option>
            <option value="entc" onclick="entc_function" >Electronic and Tele.</option>
          </select>
        </div>

    <div> 
    <label for="Divisions">Choose a Division:</label>
    <select  name="Division" id="Divisions">
      
      <optgroup label="Mechanical">
        <option value=6 >BMW</option>
        <option value=7>Audi</option>
        <option value=8 >Bugaati</option>
      </optgroup>
    
      <optgroup label="Computer Science">
        <option value=1>Linux</option>
        <option value=2>Google</option>
        <option value=3>Ubuntu</option>
      </optgroup>
    
      <optgroup label="ENTC">
        <option value=4>Arduino</option>
        <option value=5>Sensor</option>
      </optgroup>
    </select>
    </div>

    
        <button type="submit" name="view_attendence" class="view_button">View attendence</button>
      </div>
    </form>
    <a href="students.php"><button >Add Students in Database</button></a>
        <a href="index.php"><button >Submit Attendence</button></a>
    
    <script src="index.js"></script>
</body>
</html>

    