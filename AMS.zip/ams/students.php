<?php
  
  require 'vendor/autoload.php';
  use PhpOffice\PhpSpreadsheet\Spreadsheet;
  session_start();


if (isset($_POST["submit_button"])) {
    


  //setting up database connection
$servername = "127.0.0.1:3307";
$username = "root";
$password = "yash2001";
$db="ams";

$con = mysqli_connect($servername , $username, $password , $db);



if(!$con){
  die("connection failed due to the following error  " . $con->connect_error);
}
else{
  echo "<h1>Connected Successfully</h1>";
}





//valid extentions
$allowed_files = ["xls" , "csv" , "xlsx"];

//split the name revesived fro, user along .
$file_name = $_FILES['myfile']['name'];
$checking = explode("." , $file_name);

//checking if extention is is valid or not
  if ( in_array(end($checking) , $allowed_files) ) {

    //creating a reader to read file
    $target_path = $_FILES['myfile']["tmp_name"];
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($target_path);
    //storing sheet into array
    $student = $spreadsheet->getActiveSheet()->toArray();
    
    
    //getting each element of  every row 
    for($i=0 ; $i<count($student)-1 ; $i++) {
      $prn=$student[$i+1][0];
      $roll_number=$student[$i+1][1];
      $student_name=$student[$i+1][2];
      $student_div=$student[$i+1][3];
      $department_name=$student[$i+1][4];
      $email=$student[$i+1][5];
      $password=$student[$i+1][6];

      $sql = "INSERT INTO `student` (`prn`, `roll_number`, `student_name`, `student_div`,  `email`, `password`) VALUES ('$prn', '$roll_number', '$student_name' ,' $student_div' , '$email' , '$password')";
      
      if (mysqli_query($con, $sql)) {
        echo "<br>New record created successfully";
      } else {
        echo "Error occured: " . $sql . "<br>" . mysqli_error($con);
      }
     
    };

    }
  else {
    $_SESSION["status"]="Invalid File";
    header("location : index.php");
    exit(0);
    };

    $con->close();


}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>accept attendence</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="container">
        <h1>WElCOME , TEACHER :)</h1>
        <p> ADD Students to college database</p>
        
    </div>

    <form action="students.php" method="post" enctype="multipart/form-data" >
      

 

    <div>
      <label for="myfile">Select a file:</label>
      <input type="file" id="myfile" name="myfile"></div>
      <div>
        <button type="submit" name="submit_button">SubmitS</button>
      </div>
    </form>
    
    <a href="index.php" style="color:tomato;"><button >Submit Attendence</button></a>
    <a href="fetch.php"><button >View Attendence</button></a>

    <script src="index.js"></script>
</body>
</html>

