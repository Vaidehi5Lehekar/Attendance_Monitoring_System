<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<style>
    *{
        margin = 0;
        padding = 0;

    }

    .container{
        background-color : #f8c79d;
        padding : 20px 20px;
    }
</style>

</head>
<body>
    <Div class="container">
        <h4>You are coding with yash</h4>
        <h3>Conditional Statements</h3>

        <?php
            //Condtional Statements
            $work_status= FALSE;
            if($work_status){
                echo "<br>You can Go to Play !";

            }
            else {
                echo " You are not allowed to play ";
                echo "<br>Complete Your work first!";
            }
            

            //Arrays
            echo "<br><h3>Arrays & Loops</h3>";
            $div = array("linux" , "Google" ,  "Microsoft" , "Ubuntu");
            for ($i=0; $i < 4; $i++) { 
                echo " Student is from ";
            echo $div[$i];
            echo " division<br>";
            
            }

            $Students = array("aaryan" , "salim" , "sohel" , "Ram");
            $count = 0 ;
            while($count < count($Students)){
                echo "<br> Student Name is ";
                echo  ($Students[$count]);
                $count++;
            }

            foreach ($Students as $baccha) {
               echo "<br>baccha ";
               echo $baccha;
            }

            // Functions
            function fibonaci($number){
                $start1 =0;
                $start2 = 1;

                echo "<br><br> 0";
                for ($i=0; $i < $number-1; $i++) { 
                   echo "<br> ";
                   echo "<br>";
                   echo $start2;
                   $temp = $start2;
                   $start2 += $start1;
                   $start1 = $temp;
                }
            };

            fibonaci(4);

            // STRINGS 
            // String Concatination
            $input_string = "yash";
            echo "<br> Name of the student is " .$input_string . " and he is learning PHP right now";
            //length of string
            $length = strlen($input_string);
            echo "<br> there are " . $length . " caracters in string " . $input_string;
            // sub string search
            echo "<br>Letter s is present at " . strpos( $input_string , "s" ) . " in String " . $input_string;
            // word count in string
            $input_string = " You are coding with a Pro Coder";
            echo "<br> There are " . str_word_count($input_string) . " words in " . $input_string;
            //reverse
            echo "<br> reverse of string ". $input_string . ' is "' . strrev($input_string) . '"';
            //replace
            $new_str =  str_replace('coding' , 'studing' , $input_string );
            echo " <br> After replacing 'coding' by 'studing' " . $input_string . " becomes " . $new_str;
        ?>
        
    </Div>
    
</body>
</html>